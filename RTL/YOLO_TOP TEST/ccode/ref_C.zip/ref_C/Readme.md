# ref_C 資料夾

## 1. axi_dma.c
axi dma初始化

## 2. conv_ip.c
dma傳輸

## 3. main.c
main function

## 4. read_data.c
SD卡讀取

## 5. 其他設定用的檔案